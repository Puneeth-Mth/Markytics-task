from django.db import models

# Create your models here.
class Report_Incident(models.Model):
	# TODO: Define fields here
	location=models.CharField(max_length=50)
	description=models.CharField(max_length=300)
	date = models.DateField(auto_now=False, auto_now_add=False,null=True)
	time = models.TimeField(auto_now=False,auto_now_add=False)
	incident_location = models.CharField(max_length=350)
	initial_severity = models.CharField(max_length=350)
	suspented_cause=models.CharField(max_length=350)
	immediate_action_taken=models.CharField(max_length=350)
	sub_incident_types=models.CharField(max_length=350)
	reported_by=models.CharField(max_length=50)


	def __str__(self):
		return self.reported_by

    # TODO: Define custom methods here

    
    
