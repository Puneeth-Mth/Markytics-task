from django.shortcuts import render,redirect
from .models import Report_Incident 
from django.contrib.auth.forms import UserCreationForm
from django.contrib import auth
# Create your views here.
user_data=['Bot']
def index(request):

	context={'uname':user_data[0]}
	return render(request,'reportapp/html/index.html',context)


def register(request):
	user_data.clear()
	uname=upass=None
	context={}
	if request.method=='POST':
		uname=request.POST['uname']
		upass=request.POST.get('upass',False)
		cpass=request.POST['cpass']
		context={'uname':uname,'upass':upass}
		if upass==cpass:
			user_data.append(uname)
			user_data.append(upass)
			return redirect('login')
		else:
			return redirect('register')

	else:
		return render(request,'reportapp/html/register.html')
		
def login(request):
	if request.method=='POST':
		name=request.POST['lname']
		pas=request.POST['lpass']
		print(name,pas)
		if user_data[0]==name and user_data[1]==pas:
			return redirect('report_incident')
		else:
			return redirect('register')

	else:
		context={'uname':user_data[0],'upass':user_data[1]}
		return render(request,'reportapp/html/login.html',context)

def report_incident(request):
	context={'uname':user_data[0]}
	if request.method=='POST':
		location=request.POST.get('drop',False)
		incident_desc=request.POST['incident_desc']
		date=request.POST['datef']
		time=request.POST['timef']
		incident_loc=request.POST['incident_loc']
		intial=request.POST.get('initial',False)
		case=request.POST['case']
		action=request.POST['action']
		types=' '.join(request.POST.getlist('types'))
		person=request.POST['person']
		ri=Report_Incident(location=location,description=incident_desc
			,date=date,time=time,incident_location=incident_loc,initial_severity=intial
			,suspented_cause=case,immediate_action_taken=action
			,sub_incident_types=types
			,reported_by=person)
		ri.save()

		return redirect('report_list')
	else:
		return render(request,'reportapp/html/report_incident.html',context)

def report_list(request):
	report_list=Report_Incident.objects.all()
	context={'report_list':report_list,'uname':user_data[0]}
	return render(request,'reportapp/html/report_list.html',context)

def logout(request):
	auth.logout(request)
	user_data.clear()
	user_data.append('bot')
	return redirect('home')