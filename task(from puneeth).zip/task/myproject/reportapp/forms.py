from django import forms

class FORMNAME(forms.Form):
	pass
	
    # TODO: Define form fields here
